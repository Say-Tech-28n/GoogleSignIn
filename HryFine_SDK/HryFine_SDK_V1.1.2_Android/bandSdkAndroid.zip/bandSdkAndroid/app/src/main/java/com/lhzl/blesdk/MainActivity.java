package com.lhzl.blesdk;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.gson.Gson;
import com.lhzl.blelib.BleDeviceConfig;
import com.lhzl.blelib.BleManager;
import com.lhzl.blelib.GlobalVariable;
import com.lhzl.blelib.SetCallbackStatus;
import com.lhzl.blelib.WriteCommandToBle;
import com.lhzl.blelib.bean.AlarmClockBean;
import com.lhzl.blelib.bean.BloodOxygenBean;
import com.lhzl.blelib.bean.BloodPressureBean;
import com.lhzl.blelib.bean.DayStepBean;
import com.lhzl.blelib.bean.HeartRateBean;
import com.lhzl.blelib.bean.SleepInfoBean;
import com.lhzl.blelib.bean.TemperatureBean;
import com.lhzl.blelib.bledata.BleDataProcessing;
import com.lhzl.blelib.exception.BleException;
import com.lhzl.blelib.listener.ConnectStateListener;
import com.lhzl.blelib.listener.DialSizeChangeListener;
import com.lhzl.blelib.listener.OnAlarmClockChangeListener;
import com.lhzl.blelib.listener.OnBindDeviceListener;
import com.lhzl.blelib.listener.OnDataChangeListener;
import com.lhzl.blelib.listener.OnFindPhoneListener;
import com.lhzl.blelib.listener.OnMeasureExitListener;
import com.lhzl.blelib.listener.OnMusicControlListener;
import com.lhzl.blelib.listener.OnReadBatteryListener;
import com.lhzl.blelib.listener.OnRemoteCameraListener;
import com.lhzl.blelib.listener.OnSettingInfoChangeListener;
import com.lhzl.blelib.listener.OnSettingResultListener;
import com.lhzl.blelib.listener.SyncStateListener;
import com.lhzl.blelib.ota.OTACommandUtils;
import com.lhzl.blelib.ota.OTAUtils;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements ConnectStateListener, OnBindDeviceListener, OnReadBatteryListener, OnSettingResultListener, OnRemoteCameraListener, OnDataChangeListener, SyncStateListener, OnFindPhoneListener, OnAlarmClockChangeListener, OnSettingInfoChangeListener, OnMusicControlListener, OnMeasureExitListener,
        DialSizeChangeListener {

    private final static String TAG = MainActivity.class.getSimpleName();

    LinearLayout settingLl;
    Gson gson = new Gson();
    ArrayAdapter<String> languageSpAdapter;

    Spinner alarmHourSp, alarmMinSp;
    CheckBox alarmMonCheckBox, alarmTuesCheckBox, alarmWedCheckBox, alarmThurCheckBox, alarmFriCheckBox, alarmSatCheckBox, alarmSunCheckBox;
    Spinner targetStepSp;
    Spinner genderSp;
    EditText ageEt, heightEt, weightEt;
    Switch sedentaryEnableSwitch, lunchBreakSwitch;
    Spinner sedentaryTimeSp;
    Spinner sedentaryStartTimeSp, sedentaryEndTimeSp;
    EditText sedentaryStepEt;
    CheckBox sedentaryMonCheckBox, sedentaryTuesCheckBox, sedentaryWedCheckBox, sedentaryThurCheckBox, sedentaryFriCheckBox, sedentarySatCheckBox, sedentarySunCheckBox;
    Spinner wearHandSp;
    Switch callSwitch, smsSwitch, wechatSwitch, qqSwitch, facebookSwitch, twitterSwitch, skypeSwitch, lineSwitch, whatsappSwitch, kakaotalkSwitch, instagramSwitch;
    Switch raiseBrightenEnableSwitch;
    Spinner raiseBrightenStartHourSp, raiseBrightenStartMinSp, raiseBrightenEndHourSp, raiseBrightenEndMinSp;
    Switch sleepMonitorEnableSwitch;
    Spinner sleepMonitorStartHourSp, sleepMonitorStartMinSp, sleepMonitorEndHourSp, sleepMonitorEndMinSp;
    Spinner msgTypeSp;
    EditText msgEt;
    Switch dndEnableSwitch;
    Spinner dndStartHourSp, dndStartMinSp, dndEndHourSp, dndEndMinSp;
    Spinner languageSp;
    Switch hrAutoTestEnableSwitch, hrAutoTestSleepSwitch;
    Spinner hrAutoTestStartHourSp, hrAutoTestStartMinSp, hrAutoTestEndHourSp, hrAutoTestEndMinSp, hrAutoTestCycleSp;
    Switch hourUnitSwitch;
    Switch unitSystemSwitch;
    Switch temperatureAutoTestEnableSwitch;
    Spinner temperatureAutoTestStartHourSp, temperatureAutoTestStartMinSp, temperatureAutoTestEndHourSp, temperatureAutoTestEndMinSp, temperatureAutoTestCycleSp;
    Switch stepAutoUpdateSwitch;

    int alarmHour = 0, alarmMin = 0;
    int targetStep = 1000;
    int gender = 0;
    int sedentaryTime = 45, sedentaryStartTime = 0, sedentaryEndTime = 0;
    boolean isLeft = true;
    int raiseBrightenStartHour = 0, raiseBrightenStartMin = 0, raiseBrightenEndHour = 0, raiseBrightenEndMin = 0;
    int sleepMonitorStartHour = 0, sleepMonitorStartMin = 0, sleepMonitorEndHour = 0, sleepMonitorEndMin = 0;
    int msgType = 1;
    int dndStartHour = 0, dndStartMin = 0, dndEndHour = 0, dndEndMin = 0;
    int languageCode = 0;
    String[] deviceLanguageArr;
    int hrAutoTestStartHour = 0, hrAutoTestStartMin = 0, hrAutoTestEndHour = 0, hrAutoTestEndMin = 0;
    int hrAutoTestCycle = 60;
    int temperatureAutoTestStartHour = 0, temperatureAutoTestStartMin = 0, temperatureAutoTestEndHour = 0, temperatureAutoTestEndMin = 0;
    int temperatureAutoTestCycle = 60;
    int dialSize = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        List<String> list = new ArrayList<>();
        list.add(Manifest.permission.ACCESS_FINE_LOCATION);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            list.add(Manifest.permission.BLUETOOTH_SCAN);
            list.add(Manifest.permission.BLUETOOTH_CONNECT);
        }
        String[] permissions = new String[list.size()];
        list.toArray(permissions);
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, permissions, 1);
                break;
            }
        }

        settingLl = findViewById(R.id.main_setting_ll);

        findViewById(R.id.main_scan_device_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, BleScanActivity.class));
            }
        });

        findViewById(R.id.main_get_battery_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WriteCommandToBle.getDeviceBattery();
            }
        });

        findViewById(R.id.main_unbind_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WriteCommandToBle.unbindDevice();
            }
        });

        findViewById(R.id.main_set_time_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WriteCommandToBle.setDeviceTime();
            }
        });

        alarmHourSp = findViewById(R.id.main_alarm_hour_sp);
        alarmMinSp = findViewById(R.id.main_alarm_min_sp);
        alarmMonCheckBox = findViewById(R.id.main_alarm_mon_cb);
        alarmTuesCheckBox = findViewById(R.id.main_alarm_tues_cb);
        alarmWedCheckBox = findViewById(R.id.main_alarm_wed_cb);
        alarmThurCheckBox = findViewById(R.id.main_alarm_thur_cb);
        alarmFriCheckBox = findViewById(R.id.main_alarm_fri_cb);
        alarmSatCheckBox = findViewById(R.id.main_alarm_sat_cb);
        alarmSunCheckBox = findViewById(R.id.main_alarm_sun_cb);
        alarmHourSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                alarmHour = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        alarmMinSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                alarmMin = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        findViewById(R.id.main_set_alarm_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<AlarmClockBean> alarmList = new ArrayList<>();
                AlarmClockBean clockBean = new AlarmClockBean();
                clockBean.setHour(alarmHour);
                clockBean.setMinute(alarmMin);
                clockBean.setRepeat((alarmMonCheckBox.isChecked() ? GlobalVariable.MONDAY : 0x00)
                        | (alarmTuesCheckBox.isChecked() ? GlobalVariable.TUESDAY : 0x00)
                        | (alarmWedCheckBox.isChecked() ? GlobalVariable.WEDNESDAY : 0x00)
                        | (alarmThurCheckBox.isChecked() ? GlobalVariable.THURSDAY : 0x00)
                        | (alarmFriCheckBox.isChecked() ? GlobalVariable.FRIDAY : 0x00)
                        | (alarmSatCheckBox.isChecked() ? GlobalVariable.SATURDAY : 0x00)
                        | (alarmSunCheckBox.isChecked() ? GlobalVariable.SUNDAY : 0x00));
                alarmList.add(clockBean);
                WriteCommandToBle.setAlarmClock(alarmList);
            }
        });
        findViewById(R.id.main_clear_alarm_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WriteCommandToBle.setAlarmClock(null);
            }
        });

        targetStepSp = findViewById(R.id.main_step_target_sp);
        targetStepSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                targetStep = Integer.parseInt((String) targetStepSp.getAdapter().getItem(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        findViewById(R.id.main_set_target_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WriteCommandToBle.setTargetStep(targetStep);
            }
        });

        genderSp = findViewById(R.id.main_gender_sp);
        ageEt = findViewById(R.id.main_age_et);
        heightEt = findViewById(R.id.main_height_et);
        weightEt = findViewById(R.id.main_weight_et);
        genderSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                gender = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        findViewById(R.id.main_set_profile_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String age = ageEt.getText().toString();
                String height = heightEt.getText().toString();
                String weight = weightEt.getText().toString();
                if (TextUtils.isEmpty(age) || TextUtils.isEmpty(height) || TextUtils.isEmpty(weight)) {
                    return;
                }
                WriteCommandToBle.setProfile(gender, Integer.parseInt(age), Integer.parseInt(height), Integer.parseInt(weight));
            }
        });

        sedentaryEnableSwitch = findViewById(R.id.main_sedentary_enable_switch);
        lunchBreakSwitch = findViewById(R.id.main_sedentary_lunch_break_switch);
        sedentaryStepEt = findViewById(R.id.main_sedentary_step_et);
        sedentaryTimeSp = findViewById(R.id.main_sedentary_time_sp);
        sedentaryStartTimeSp = findViewById(R.id.main_sedentary_start_time_sp);
        sedentaryEndTimeSp = findViewById(R.id.main_sedentary_end_time_sp);
        sedentaryMonCheckBox = findViewById(R.id.main_sedentary_mon_cb);
        sedentaryTuesCheckBox = findViewById(R.id.main_sedentary_tues_cb);
        sedentaryWedCheckBox = findViewById(R.id.main_sedentary_wed_cb);
        sedentaryThurCheckBox = findViewById(R.id.main_sedentary_thur_cb);
        sedentaryFriCheckBox = findViewById(R.id.main_sedentary_fri_cb);
        sedentarySatCheckBox = findViewById(R.id.main_sedentary_sat_cb);
        sedentarySunCheckBox = findViewById(R.id.main_sedentary_sun_cb);
        sedentaryTimeSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sedentaryTime = Integer.parseInt((String) sedentaryTimeSp.getAdapter().getItem(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        sedentaryStartTimeSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sedentaryStartTime = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        sedentaryEndTimeSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sedentaryEndTime = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        findViewById(R.id.main_set_sedentary_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String step = sedentaryStepEt.getText().toString();
                if (TextUtils.isEmpty(step)) {
                    return;
                }
                if (sedentaryStartTime == sedentaryEndTime) {
                    showToast("开始时间和结束时间不能相同");
                    return;
                }
                WriteCommandToBle.setSedentaryRemind(sedentaryEnableSwitch.isChecked(),
                        lunchBreakSwitch.isChecked(),
                        Integer.parseInt(step),
                        sedentaryTime,
                        sedentaryStartTime,
                        sedentaryEndTime,
                        (sedentaryMonCheckBox.isChecked() ? GlobalVariable.MONDAY : 0x00)
                                | (sedentaryTuesCheckBox.isChecked() ? GlobalVariable.TUESDAY : 0x00)
                                | (sedentaryWedCheckBox.isChecked() ? GlobalVariable.WEDNESDAY : 0x00)
                                | (sedentaryThurCheckBox.isChecked() ? GlobalVariable.THURSDAY : 0x00)
                                | (sedentaryFriCheckBox.isChecked() ? GlobalVariable.FRIDAY : 0x00)
                                | (sedentarySatCheckBox.isChecked() ? GlobalVariable.SATURDAY : 0x00)
                                | (sedentarySunCheckBox.isChecked() ? GlobalVariable.SUNDAY : 0x00));
            }
        });

        wearHandSp = findViewById(R.id.main_wear_hand_sp);
        wearHandSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                isLeft = position == 0;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        findViewById(R.id.main_set_wear_hand_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WriteCommandToBle.setWearHand(isLeft);
            }
        });

        callSwitch = findViewById(R.id.main_notify_call_switch);
        smsSwitch = findViewById(R.id.main_notify_sms_switch);
        wechatSwitch = findViewById(R.id.main_notify_wechat_switch);
        qqSwitch = findViewById(R.id.main_notify_qq_switch);
        facebookSwitch = findViewById(R.id.main_notify_facebook_switch);
        twitterSwitch = findViewById(R.id.main_notify_twitter_switch);
        skypeSwitch = findViewById(R.id.main_notify_skype_switch);
        lineSwitch = findViewById(R.id.main_notify_line_switch);
        whatsappSwitch = findViewById(R.id.main_notify_whatsapp_switch);
        kakaotalkSwitch = findViewById(R.id.main_notify_kakaotalk_switch);
        instagramSwitch = findViewById(R.id.main_notify_instagram_switch);
        findViewById(R.id.main_set_notify_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WriteCommandToBle.setNotify(callSwitch.isChecked(),
                        smsSwitch.isChecked(),
                        wechatSwitch.isChecked(),
                        qqSwitch.isChecked(),
                        facebookSwitch.isChecked(),
                        twitterSwitch.isChecked(),
                        skypeSwitch.isChecked(),
                        lineSwitch.isChecked(),
                        whatsappSwitch.isChecked(),
                        kakaotalkSwitch.isChecked(),
                        instagramSwitch.isChecked());
            }
        });

        ((Switch) findViewById(R.id.main_vibration_switch)).setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                WriteCommandToBle.setVibrationEnable(isChecked);
            }
        });

        raiseBrightenEnableSwitch = findViewById(R.id.main_raise_brighten_switch);
        raiseBrightenStartHourSp = findViewById(R.id.main_raise_brighten_start_hour_sp);
        raiseBrightenStartMinSp = findViewById(R.id.main_raise_brighten_start_min_sp);
        raiseBrightenEndHourSp = findViewById(R.id.main_raise_brighten_end_hour_sp);
        raiseBrightenEndMinSp = findViewById(R.id.main_raise_brighten_end_min_sp);
        raiseBrightenStartHourSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                raiseBrightenStartHour = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        raiseBrightenStartMinSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                raiseBrightenStartMin = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        raiseBrightenEndHourSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                raiseBrightenEndHour = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        raiseBrightenEndMinSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                raiseBrightenEndMin = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        findViewById(R.id.main_set_raise_brighten_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (raiseBrightenStartHour * 60 + raiseBrightenStartMin == raiseBrightenEndHour * 60 + raiseBrightenEndMin) {
                    showToast("开始时间和结束时间不能相同");
                    return;
                }
                WriteCommandToBle.setRaiseBrighten(raiseBrightenEnableSwitch.isChecked(),
                        raiseBrightenStartHour,
                        raiseBrightenStartMin,
                        raiseBrightenEndHour,
                        raiseBrightenEndMin);
            }
        });

        findViewById(R.id.main_find_band_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WriteCommandToBle.findBand();
            }
        });

        findViewById(R.id.main_set_photo_open_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WriteCommandToBle.setCameraOpen(true);
            }
        });
        findViewById(R.id.main_set_photo_close_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WriteCommandToBle.setCameraOpen(false);
            }
        });

        findViewById(R.id.main_set_hr_test_open_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WriteCommandToBle.setHrTestEnable(true);
            }
        });
        findViewById(R.id.main_set_hr_test_close_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WriteCommandToBle.setHrTestEnable(false);
            }
        });

        findViewById(R.id.main_set_temperature_open_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!BleDeviceConfig.IS_SUPPORT_TEMPERATURE) {
                    showToast("设备不支持体温功能");
                    return;
                }
                WriteCommandToBle.setTemperatureTestEnable(true);
            }
        });
        findViewById(R.id.main_set_temperature_close_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!BleDeviceConfig.IS_SUPPORT_TEMPERATURE) {
                    showToast("设备不支持体温功能");
                    return;
                }
                WriteCommandToBle.setTemperatureTestEnable(false);
            }
        });

        findViewById(R.id.main_set_bo_open_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!BleDeviceConfig.IS_SUPPORT_BLOOD_OXYGEN) {
                    showToast("设备不支持血氧功能");
                    return;
                }
                WriteCommandToBle.setBOTestEnable(true);
            }
        });
        findViewById(R.id.main_set_bo_close_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!BleDeviceConfig.IS_SUPPORT_TEMPERATURE) {
                    showToast("设备不支持血氧功能");
                    return;
                }
                WriteCommandToBle.setBOTestEnable(false);
            }
        });

        findViewById(R.id.main_set_bp_open_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WriteCommandToBle.setBPTestEnable(true);
            }
        });
        findViewById(R.id.main_set_bp_close_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WriteCommandToBle.setBPTestEnable(false);
            }
        });

        sleepMonitorEnableSwitch = findViewById(R.id.main_sleep_monitor_switch);
        sleepMonitorStartHourSp = findViewById(R.id.main_sleep_monitor_start_hour_sp);
        sleepMonitorStartMinSp = findViewById(R.id.main_sleep_monitor_start_min_sp);
        sleepMonitorEndHourSp = findViewById(R.id.main_sleep_monitor_end_hour_sp);
        sleepMonitorEndMinSp = findViewById(R.id.main_sleep_monitor_end_min_sp);
        sleepMonitorStartHourSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sleepMonitorStartHour = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        sleepMonitorStartMinSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sleepMonitorStartMin = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        sleepMonitorEndHourSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sleepMonitorEndHour = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        sleepMonitorEndMinSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                sleepMonitorEndMin = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        findViewById(R.id.main_set_sleep_monitor_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (sleepMonitorStartHour * 60 + sleepMonitorStartMin == sleepMonitorEndHour * 60 + sleepMonitorEndMin) {
                    showToast("开始时间和结束时间不能相同");
                    return;
                }
                WriteCommandToBle.setSleepMonitor(sleepMonitorEnableSwitch.isChecked(),
                        sleepMonitorStartHour,
                        sleepMonitorStartMin,
                        sleepMonitorEndHour,
                        sleepMonitorEndMin);
            }
        });

        findViewById(R.id.main_send_call_name_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WriteCommandToBle.sendInCall("测试");
            }
        });
        findViewById(R.id.main_send_call_num_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WriteCommandToBle.sendInCall("13011111111");
            }
        });

        msgTypeSp = findViewById(R.id.main_send_message_type_sp);
        msgEt = findViewById(R.id.main_message_et);
        msgTypeSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                msgType = position + 1;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        findViewById(R.id.main_send_message_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String msg = msgEt.getText().toString();
                if (TextUtils.isEmpty(msg)) {
                    return;
                }
                WriteCommandToBle.sendMessage(msgType, msg);
            }
        });

        dndEnableSwitch = findViewById(R.id.main_dnd_switch);
        dndStartHourSp = findViewById(R.id.main_dnd_start_hour_sp);
        dndStartMinSp = findViewById(R.id.main_dnd_start_min_sp);
        dndEndHourSp = findViewById(R.id.main_dnd_end_hour_sp);
        dndEndMinSp = findViewById(R.id.main_dnd_end_min_sp);
        dndStartHourSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                dndStartHour = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        dndStartMinSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                dndStartMin = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        dndEndHourSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                dndEndHour = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        dndEndMinSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                dndEndMin = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        findViewById(R.id.main_set_dnd_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (dndStartHour * 60 + dndStartMin == dndEndHour * 60 + dndEndMin) {
                    showToast("开始时间和结束时间不能相同");
                    return;
                }
                WriteCommandToBle.setDNDSetting(dndEnableSwitch.isChecked(),
                        dndStartHour,
                        dndStartMin,
                        dndEndHour,
                        dndEndMin);
            }
        });

        languageSpAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new ArrayList<String>());
        languageSpAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        languageSp = findViewById(R.id.main_language_sp);
        languageSp.setAdapter(languageSpAdapter);
        languageSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                languageCode = BleDeviceConfig.LanguageCodeList.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        findViewById(R.id.main_set_language_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WriteCommandToBle.setLanguage(languageCode);
            }
        });

        hrAutoTestEnableSwitch = findViewById(R.id.main_hr_auto_test_enable_switch);
        hrAutoTestSleepSwitch = findViewById(R.id.main_hr_auto_test_sleep_switch);
        hrAutoTestStartHourSp = findViewById(R.id.main_hr_auto_test_start_hour_sp);
        hrAutoTestStartMinSp = findViewById(R.id.main_hr_auto_test_start_min_sp);
        hrAutoTestEndHourSp = findViewById(R.id.main_hr_auto_test_end_hour_sp);
        hrAutoTestEndMinSp = findViewById(R.id.main_hr_auto_test_end_min_sp);
        hrAutoTestCycleSp = findViewById(R.id.main_hr_auto_test_cycle_sp);
        hrAutoTestStartHourSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                hrAutoTestStartHour = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        hrAutoTestStartMinSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                hrAutoTestStartMin = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        hrAutoTestEndHourSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                hrAutoTestEndHour = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        hrAutoTestEndMinSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                hrAutoTestEndMin = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        hrAutoTestCycleSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                hrAutoTestCycle = Integer.parseInt((String) hrAutoTestCycleSp.getAdapter().getItem(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        findViewById(R.id.main_set_hr_auto_test_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (hrAutoTestStartHour * 60 + hrAutoTestStartMin == hrAutoTestEndHour * 60 + hrAutoTestEndMin) {
                    showToast("开始时间和结束时间不能相同");
                    return;
                }
                WriteCommandToBle.setHeartAuto(hrAutoTestEnableSwitch.isChecked(),
                        hrAutoTestSleepSwitch.isChecked(),
                        hrAutoTestStartHour,
                        hrAutoTestStartMin,
                        hrAutoTestEndHour,
                        hrAutoTestEndMin,
                        hrAutoTestCycle);
            }
        });

        hourUnitSwitch = findViewById(R.id.main_set_hour_unit_switch);
        hourUnitSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (!BleDeviceConfig.IS_SUPPORT_12_24_HOUR) {
                    showToast("设备不支持12小时显示");
                    hourUnitSwitch.setChecked(!isChecked);
                    return;
                }
                WriteCommandToBle.setHourUnit(isChecked);
            }
        });

        unitSystemSwitch = findViewById(R.id.main_set_unit_system_switch);
        unitSystemSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (!BleDeviceConfig.IS_SUPPORT_IMPERIAL) {
                    showToast("设备不支持英制单位");
                    unitSystemSwitch.setChecked(!isChecked);
                    return;
                }
                WriteCommandToBle.setUnitSystem(isChecked);
            }
        });

        temperatureAutoTestEnableSwitch = findViewById(R.id.main_temperature_auto_test_enable_switch);
        temperatureAutoTestStartHourSp = findViewById(R.id.main_temperature_auto_test_start_hour_sp);
        temperatureAutoTestStartMinSp = findViewById(R.id.main_temperature_auto_test_start_min_sp);
        temperatureAutoTestEndHourSp = findViewById(R.id.main_temperature_auto_test_end_hour_sp);
        temperatureAutoTestEndMinSp = findViewById(R.id.main_temperature_auto_test_end_min_sp);
        temperatureAutoTestCycleSp = findViewById(R.id.main_temperature_auto_test_cycle_sp);
        temperatureAutoTestStartHourSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                temperatureAutoTestStartHour = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        temperatureAutoTestStartMinSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                temperatureAutoTestStartMin = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        temperatureAutoTestEndHourSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                temperatureAutoTestEndHour = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        temperatureAutoTestEndMinSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                temperatureAutoTestEndMin = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        temperatureAutoTestCycleSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                temperatureAutoTestCycle = Integer.parseInt((String) temperatureAutoTestCycleSp.getAdapter().getItem(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        findViewById(R.id.main_set_temperature_auto_test_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!BleDeviceConfig.IS_SUPPORT_TEMPERATURE) {
                    showToast("设备不支持体温功能");
                    return;
                }
                if (temperatureAutoTestStartHour * 60 + temperatureAutoTestStartMin == temperatureAutoTestEndHour * 60 + temperatureAutoTestEndMin) {
                    showToast("开始时间和结束时间不能相同");
                    return;
                }
                WriteCommandToBle.setTemperatureAuto(temperatureAutoTestEnableSwitch.isChecked(),
                        temperatureAutoTestStartHour,
                        temperatureAutoTestStartMin,
                        temperatureAutoTestEndHour,
                        temperatureAutoTestEndMin,
                        temperatureAutoTestCycle);
            }
        });

        findViewById(R.id.main_set_weather_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!BleDeviceConfig.IS_SUPPORT_WEATHER) {
                    showToast("设备不支持天气功能");
                    return;
                }
                WriteCommandToBle.setTodayWeather(1, 23, 26, 24, "深圳");
            }
        });

        findViewById(R.id.main_sync_all_data_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WriteCommandToBle.syncAllHistory();
            }
        });

        findViewById(R.id.main_sync_today_data_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WriteCommandToBle.syncTodayHistory();
            }
        });

        stepAutoUpdateSwitch = findViewById(R.id.main_step_auto_update_switch);
        stepAutoUpdateSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                WriteCommandToBle.setStepAutoUpdate(isChecked);
            }
        });

        findViewById(R.id.main_restore_factory_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WriteCommandToBle.restoreFactory();
            }
        });

        findViewById(R.id.main_get_setting_info_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WriteCommandToBle.requestSettingInfo();
            }
        });

        findViewById(R.id.main_get_alarm_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WriteCommandToBle.requestAlarmClock();
            }
        });

        findViewById(R.id.main_get_dial_size_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (BleDeviceConfig.IS_SUPPORT_DIAL_PUSH) {
                    WriteCommandToBle.requestDialSize();
                } else {
                    showToast("设备不支持此功能");
                }
            }
        });
        findViewById(R.id.main_push_dial_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AssetManager assetManager = getAssets();
                InputStream input = null;
                try {
                    input = assetManager.open("A0E6.bin");
                    int size = input.available();
                    byte[] buffer = new byte[size];
                    input.read(buffer);
                    input.close();
                    if (buffer.length < dialSize) {
                        new OTAUtils(OTACommandUtils.CMD_DIAL, OTACommandUtils.DIAL_DEFAULT, buffer, new OTAUtils.Callback() {
                            @Override
                            public void progress(int progress) {

                            }

                            @Override
                            public void OTAFinish() {
                                runOnUiThread(() -> {
                                    showToast("传输完成");
                                });
                            }

                            @Override
                            public void OTAError() {
                                runOnUiThread(() -> {
                                    showToast("传输失败");
                                });
                            }
                        });
                    } else {
                        showToast("文件大小超出");
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });

        BleManager.getInstance().addConnectStateListener(this);
        BleDataProcessing.getInstance().setOnBindDeviceListener(this);
        BleDataProcessing.getInstance().setOnReadBatteryListener(this);
        BleDataProcessing.getInstance().setOnSettingResultListener(this);
        BleDataProcessing.getInstance().setOnRemoteCameraListener(this);
        BleDataProcessing.getInstance().setOnDataChangeListener(this);
        BleDataProcessing.getInstance().setSyncStateListener(this);
        BleDataProcessing.getInstance().setOnFindPhoneListener(this);
        BleDataProcessing.getInstance().setOnAlarmClockChangeListener(this);
        BleDataProcessing.getInstance().setOnSettingInfoChangeListener(this);
        BleDataProcessing.getInstance().setOnMusicControlListener(this);
        BleDataProcessing.getInstance().setOnMeasureExitListener(this);
        BleDataProcessing.getInstance().setDialSizeChangeListener(this);

        // 已连接
        if (BleManager.getInstance().isConnect()) {
            onConnectSuccess();
        }
        BleManager.getInstance().setAutoReconnect(true);

    }

    @Override
    public void onBind(boolean isFirst) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                showToast("绑定成功");
            }
        });
    }

    @Override
    public void onRefuse() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                showToast("拒绝绑定");
            }
        });
    }

    @Override
    public void onUnbindSuccess() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                showToast("解绑成功");
            }
        });
    }

    @Override
    public void onReadBattery(final int battery) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                showToast("当前电量：" + battery);
            }
        });
    }

    @Override
    public void onSettingResult(final int key, final boolean isSuccess) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                switch (key) {
                    case SetCallbackStatus.SET_SYSTEM_TIME:
                        showToast(isSuccess ? "时间设置成功" : "时间设置失败");
                        break;

                    case SetCallbackStatus.SET_ALARM_CLOCK:
                        showToast(isSuccess ? "闹钟设置成功" : "闹钟设置失败");
                        break;

                    case SetCallbackStatus.SET_TARGET_STEP:
                        showToast(isSuccess ? "目标设置成功" : "目标设置失败");
                        break;

                    case SetCallbackStatus.SET_PROFILE:
                        showToast(isSuccess ? "用户信息设置成功" : "用户信息设置失败");
                        break;

                    case SetCallbackStatus.SET_SEDENTARY_REMIND:
                        showToast(isSuccess ? "久坐设置成功" : "久坐设置失败");
                        break;

                    case SetCallbackStatus.SET_WEAR_HAND:
                        showToast(isSuccess ? "佩戴方式设置成功" : "佩戴方式设置失败");
                        break;

                    case SetCallbackStatus.SET_NOTIFY:
                        showToast(isSuccess ? "通知设置成功" : "通知设置失败");
                        break;

                    case SetCallbackStatus.SET_VIBRATION:
                        showToast(isSuccess ? "震动设置成功" : "震动设置失败");
                        break;

                    case SetCallbackStatus.SET_RAISE_BRIGHTEN:
                        showToast(isSuccess ? "抬手亮屏设置成功" : "抬手亮屏设置失败");
                        break;

                    case SetCallbackStatus.SET_FIND_BAND:
                        showToast(isSuccess ? "找手环设置成功" : "找手环设置失败");
                        break;

                    case SetCallbackStatus.SET_PHOTO_OPEN:
                        showToast(isSuccess ? "拍照设置成功" : "拍照设置失败");
                        break;

                    case SetCallbackStatus.SET_SLEEP_MONITOR:
                        showToast(isSuccess ? "睡眠监测设置成功" : "睡眠监测设置失败");
                        break;

                    case SetCallbackStatus.SET_DND_MODE:
                        showToast(isSuccess ? "勿扰模式设置成功" : "勿扰模式设置失败");
                        break;

                    case SetCallbackStatus.SET_LANGUAGE:
                        showToast(isSuccess ? "语言设置成功" : "语言设置失败");
                        break;

                    case SetCallbackStatus.SET_HR_AUTO_TEST:
                        showToast(isSuccess ? "心率自动测量设置成功" : "心率自动测量设置失败");
                        break;

                    case SetCallbackStatus.SET_TEMPERATURE_AUTO_TEST:
                        showToast(isSuccess ? "体温自动测量设置成功" : "体温自动测量设置失败");
                        break;

                    case SetCallbackStatus.SET_HOUR_UNIT:
                        showToast(isSuccess ? "时间显示设置成功" : "时间显示设置失败");
                        break;

                    case SetCallbackStatus.SET_UNIT_SYSTEM:
                        showToast(isSuccess ? "单位显示设置成功" : "单位显示设置失败");
                        break;

                    case SetCallbackStatus.SET_TODAY_WEATHER:
                        showToast(isSuccess ? "天气设置成功" : "天气设置失败");
                        break;
                }
            }
        });
    }

    @Override
    public void onStartConnect() {

    }

    @Override
    public void onConnectSuccess() {
        String[] allLanguageArr = getResources().getStringArray(R.array.language_arr);
        if (BleDeviceConfig.LanguageCodeList.size() > 0) {
            deviceLanguageArr = new String[BleDeviceConfig.LanguageCodeList.size()];
            for (int i = 0; i < BleDeviceConfig.LanguageCodeList.size(); i++) {
                deviceLanguageArr[i] = allLanguageArr[BleDeviceConfig.LanguageCodeList.get(i)];
            }
        }
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (deviceLanguageArr != null) {
                    languageSpAdapter.clear();
                    languageSpAdapter.addAll(deviceLanguageArr);
                }
                settingLl.setVisibility(View.VISIBLE);
            }
        });
    }

    @Override
    public void onConnectFail(BleException exception) {
        Log.e(TAG, "onConnectFail: " + exception.toString());
    }

    @Override
    public void onDisConnected() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                settingLl.setVisibility(View.GONE);
            }
        });
    }

    @Override
    public void onOpenCamera() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                showToast("打开相机");
            }
        });
    }

    @Override
    public void onTakePicture() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                showToast("拍照");
            }
        });
    }

    @Override
    public void onCloseCamera() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                showToast("关闭相机");
            }
        });
    }

    @Override
    public void onDayStepChange(DayStepBean dayStepBean) {
        String msg = "步数历史数据：" + dayStepBean.getDate() + " data: " + gson.toJson(dayStepBean.getHourDataList());
        Log.i(TAG, msg);
        showToast(msg);
    }

    @Override
    public void onHRChange(List<HeartRateBean> hrList) {
        String msg = "心率数据：" + gson.toJson(hrList);
        Log.i(TAG, msg);
        showToast(msg);
    }

    @Override
    public void onBPChange(List<BloodPressureBean> bpList) {
        String msg = "血压数据：" + gson.toJson(bpList);
        Log.i(TAG, msg);
        showToast(msg);
    }

    @Override
    public void onSleepChange(SleepInfoBean sleepInfoBean) {
        Log.i(TAG, "睡眠数据：" + sleepInfoBean.getDate()
                + " 深睡时间: " + sleepInfoBean.getDeepTime()
                + " 浅睡时间: " + sleepInfoBean.getLightTime()
                + " 快速眼动: " + sleepInfoBean.getRemTime()
                + " 开始时间: " + (sleepInfoBean.getStartTime() / 60) + ":" + (sleepInfoBean.getStartTime() % 60)
                + " 结束时间: " + (sleepInfoBean.getEndTime() / 60) + ":" + (sleepInfoBean.getEndTime() % 60));
    }

    @Override
    public void onRealTimeStepChange(int step, int distance, int calorie) {
        String msg = "实时步数数据：" + step + " 距离（米）: " + distance + " 卡路里（卡）：" + calorie;
        Log.i(TAG, msg);
        showToast(msg);
    }

    @Override
    public void onTemperatureChange(List<TemperatureBean> temperatureList) {
        String msg = "体温数据：" + gson.toJson(temperatureList);
        Log.i(TAG, msg);
        showToast(msg);
    }

    @Override
    public void onBOChange(BloodOxygenBean boData) {
        String msg = "血氧数据：" + gson.toJson(boData);
        Log.i(TAG, msg);
        showToast(msg);
    }

    @Override
    public void onSyncStart() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, "开始同步数据，同步结束前不要进行其他操作！", Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public void onSyncEnd() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, "数据同步结束", Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public void onFindPhone() {
        showToast("手表找手机");
    }

    @Override
    public void onFindPhoneEnd() {
        showToast("结束找手机");
    }

    @Override
    public void onChange(List<AlarmClockBean> infoList) {
        Log.i(TAG, "闹钟数据：" + gson.toJson(infoList));
    }

    @Override
    public void onHRExit() {
        Log.i(TAG, "退出心率测量");
    }

    @Override
    public void onBPExit() {
        Log.i(TAG, "退出血压测量");
    }

    @Override
    public void onTemperatureExit() {
        Log.i(TAG, "退出体温测量");
    }

    @Override
    public void onBOExit() {
        Log.i(TAG, "退出血氧测量");
    }

    @Override
    public void onMusicPlay() {
        Log.i(TAG, "音乐播放");
    }

    @Override
    public void onMusicPause() {
        Log.i(TAG, "音乐暂停");
    }

    @Override
    public void onMusicLast() {
        Log.i(TAG, "上一首");
    }

    @Override
    public void onMusicNext() {
        Log.i(TAG, "下一首");
    }

    @Override
    public void onSedentaryInfoChange(boolean enable, boolean isLunchBreakEnable, int step, int sedentaryTime, int startTime, int endTime, int repeat) {
        Log.i(TAG, "久坐提醒： 开关:" + enable + " 午休免打扰:" + isLunchBreakEnable + " 阈值步数:" + step + " 久坐时间:" + sedentaryTime
                + " 开始时间:" + startTime + " 结束时间:" + endTime + " 重复周期:" + repeat);
    }

    @Override
    public void onNotifySettingChange(boolean isTelNotify, boolean isSmsNotify, boolean isWechatNotify, boolean isQQNotify, boolean isFacebookNotify, boolean isTwitterNotify, boolean isSkypeNotify, boolean isLineNotify, boolean isWhatsappNotify, boolean isKakaoTalkNotify, boolean isInstagramNotify) {
        Log.i(TAG, "通知提醒： 来电:" + isTelNotify
                + " 短信:" + isSmsNotify
                + " 微信:" + isWechatNotify
                + " QQ:" + isQQNotify
                + " Facebook:" + isFacebookNotify
                + " Twitter:" + isTwitterNotify
                + " Skype:" + isSkypeNotify
                + " Line:" + isLineNotify
                + " Whatsapp:" + isWhatsappNotify
                + " KakaoTalk:" + isKakaoTalkNotify
                + " Instagram:" + isInstagramNotify);
    }

    @Override
    public void onSleepMonitorChange(boolean enable, int startHour, int startMin, int endHour, int endMin) {
        Log.i(TAG, "睡眠监测： 开关:" + enable + " 开始时间:" + startHour + ":" + startMin + " 结束时间:" + endHour + ":" + endMin);
    }

    @Override
    public void onWearHandChange(boolean isLeft) {
        Log.i(TAG, "佩戴方式： 是否左手佩戴:" + isLeft);
    }

    @Override
    public void onLanguageChange(int languageCode) {
        Log.i(TAG, "语言：" + languageCode);
    }

    @Override
    public void onVibrationChange(boolean enable) {
        Log.i(TAG, "震动开关：" + enable);
    }

    @Override
    public void onRaiseBrighten(boolean enable, int startHour, int startMin, int endHour, int endMin) {
        Log.i(TAG, "抬手亮屏：开关:" + enable + " 开始时间:" + startHour + ":" + startMin + " 结束时间:" + endHour + ":" + endMin);
    }

    @Override
    public void onHrAutoTestChange(boolean enable, boolean enableSleepAssist, int startHour, int startMin, int endHour, int endMin, int cycle) {
        Log.i(TAG, "心率自动测量：开关:" + enable + " 心率辅助睡眠:" + enableSleepAssist + " 开始时间:" + startHour + ":" + startMin
                + " 结束时间:" + endHour + ":" + endMin + " 周期:" + cycle);
    }

    @Override
    public void onDNDSettingChange(boolean enable, int startHour, int startMin, int endHour, int endMin) {
        Log.i(TAG, "勿扰模式：开关:" + enable + " 开始时间:" + startHour + ":" + startMin + " 结束时间:" + endHour + ":" + endMin);
    }

    @Override
    public void onTemperatureAutoTestChange(boolean enable, int startHour, int startMin, int endHour, int endMin, int cycle) {
        Log.i(TAG, "体温自动测量：开关:" + enable + " 开始时间:" + startHour + ":" + startMin + " 结束时间:" + endHour + ":" + endMin + " 周期:" + cycle);
    }

    @Override
    public void onDialSizeChange(int size) {
        Log.i(TAG, "设备支持表盘大小：" + size);
        dialSize = size;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e(TAG, "onDestroy: ");
        BleManager.getInstance().removeConnectStateListener(this);
        BleManager.getInstance().setAutoReconnect(false);
        if (BleManager.getInstance().isConnect()) {
            BleManager.getInstance().disconnectDevice();
        }
    }

    private void showToast(String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
    }
}
