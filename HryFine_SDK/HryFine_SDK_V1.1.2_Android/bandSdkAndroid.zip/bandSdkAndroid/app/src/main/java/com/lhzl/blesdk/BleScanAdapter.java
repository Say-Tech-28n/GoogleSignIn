package com.lhzl.blesdk;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.lhzl.blelib.data.BleDevice;

import java.util.ArrayList;
import java.util.List;

/**
 * 作者：houyingchen
 * 创建日期： 2020/10/12 0012
 * 类介绍：
 */
public class BleScanAdapter extends BaseAdapter {

    private LayoutInflater inflater;

    private List<BleDevice> deviceList = new ArrayList<>();

    public BleScanAdapter(Context context) {
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return deviceList.size();
    }

    @Override
    public Object getItem(int position) {
        return deviceList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_device_scan, null);
            viewHolder = new ViewHolder();
            viewHolder.mNameTv = convertView.findViewById(R.id.device_scan_name_tv);
            viewHolder.mAddressTv = convertView.findViewById(R.id.device_scan_address_tv);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        BluetoothDevice device = deviceList.get(position).getDevice();
        viewHolder.mNameTv.setText(device.getName());
        viewHolder.mAddressTv.setText(device.getAddress());
        return convertView;
    }

    void clearData() {
        deviceList.clear();
        notifyDataSetChanged();
    }

    void addDevice(BleDevice bleDevice) {
        deviceList.add(bleDevice);
        notifyDataSetChanged();
    }

    static class ViewHolder {
        TextView mNameTv;
        TextView mAddressTv;
    }
}
