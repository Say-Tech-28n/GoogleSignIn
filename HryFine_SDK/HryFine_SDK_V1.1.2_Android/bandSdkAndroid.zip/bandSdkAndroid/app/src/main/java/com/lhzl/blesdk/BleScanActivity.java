package com.lhzl.blesdk;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.lhzl.blelib.BleManager;
import com.lhzl.blelib.data.BleDevice;
import com.lhzl.blelib.exception.BleException;
import com.lhzl.blelib.listener.BleScanListener;
import com.lhzl.blelib.listener.ConnectStateListener;

import java.util.HashSet;
import java.util.Set;

public class BleScanActivity extends AppCompatActivity implements ConnectStateListener {

    Button scanBtn;

    BleScanAdapter adapter;

    Set<String> bleSet = new HashSet<>();

    boolean isConnecting = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ble_scan);

        adapter = new BleScanAdapter(this);
        final ListView listView = findViewById(R.id.scan_device_list);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (isConnecting) {
                    return;
                }
                isConnecting = true;
                if (BleManager.getInstance().isScanning()) {
                    BleManager.getInstance().stopScan();
                }
                BleManager.getInstance().connect((BleDevice) adapter.getItem(position));
            }
        });

        scanBtn = findViewById(R.id.scan_btn);
        scanBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scanDevice();
            }
        });

        BleManager.getInstance().addConnectStateListener(this);
    }

    private void scanDevice() {
        adapter.clearData();
        bleSet.clear();
        BleManager.getInstance().scan(new BleScanListener() {
            @Override
            public void onScanStarted(boolean success) {

            }

            @Override
            public void onScanning(BleDevice bleDevice) {

            }

            @Override
            public void onScanFinished() {

            }

            @Override
            public void onLeScan(BleDevice bleDevice) {
                String deviceAddress = bleDevice.getDevice().getAddress();
                if (!TextUtils.isEmpty(bleDevice.getName()) && !bleSet.contains(deviceAddress)) {
                    bleSet.add(deviceAddress);
                    adapter.addDevice(bleDevice);
                }
            }
        });
    }

    @Override
    public void onStartConnect() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(BleScanActivity.this, "开始连接", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onConnectSuccess() {
        finish();
    }

    @Override
    public void onConnectFail(BleException exception) {
        isConnecting = false;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(BleScanActivity.this, "连接失败", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onDisConnected() {
        isConnecting = false;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(BleScanActivity.this, "连接断开", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        BleManager.getInstance().removeConnectStateListener(this);
    }
}
