package com.lhzl.blesdk;

import android.app.Application;
import android.content.Context;
import android.util.Log;

import androidx.core.app.NotificationManagerCompat;

import com.lhzl.blelib.BleManager;
import com.lhzl.blelib.service.NPNotificationService;
import com.lhzl.blelib.util.NotificationMsgUtil;

import java.util.Set;

public class MyApplication extends Application {

    private static final String TAG = "MyApplication";
    private static MyApplication instance;

    public static MyApplication getApplication() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;

        BleManager.init(this);

        // App guides users to enable self start permissions

        // Determine notification bar permissions
        Log.d(TAG, "Notification: " + isEnabled(this) + NotificationMsgUtil.isServiceExisted(this, NPNotificationService.class));
        if (!isEnabled(this)) {
            NotificationMsgUtil.goToSettingNotificationAccess(this);
        }

        BleManager.getInstance().autoStart();
        BleManager.getInstance().setAutoReconnect(true);

        BleManager.getInstance().setAppPush(true);

        BleManager.setLog(true);
    }

    /**
     * Determine whether the notification permission on the message bar is authorized
     *
     * @param context
     * @return
     */
    public static boolean isEnabled(Context context) {
        Set<String> packageNames = NotificationManagerCompat.getEnabledListenerPackages(context);
        return packageNames.contains(context.getPackageName());
    }
}
